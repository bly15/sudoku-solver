$(document).ready(function() {
    $("#reset").click(function() {
        $("input").val("");
    });
});